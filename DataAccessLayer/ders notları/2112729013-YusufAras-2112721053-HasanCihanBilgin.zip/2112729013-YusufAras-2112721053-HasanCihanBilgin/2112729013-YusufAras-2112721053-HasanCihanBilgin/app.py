
from flask import Flask, render_template, request, jsonify
import cv2
import numpy as np
import base64
import matplotlib.pyplot as plt

app = Flask(__name__)

def adaptive_threshold(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                   cv2.THRESH_BINARY, 11, 2)
    return thresh

def otsu_threshold(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return thresh

def sharpen(image):
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
    return cv2.filter2D(image, -1, kernel)

def blur_image(image):
    return cv2.GaussianBlur(image, (15, 15), 0)

def add_border(image, border_size=10):
    return cv2.copyMakeBorder(image, border_size, border_size, border_size, border_size,
                              cv2.BORDER_CONSTANT, value=[0, 0, 0])

def gamma_correction(image, gamma=1.5):
    inv_gamma = 1.0 / gamma
    table = np.array([(i / 255.0) ** inv_gamma * 255 for i in range(256)]).astype("uint8")
    return cv2.LUT(image, table)

def histogram(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    plt.figure()
    plt.hist(gray.ravel(), 256, [0, 256])
    plt.title("Histogram")
    plt.xlabel("Pixel Value")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig("histogram.png")
    with open("histogram.png", "rb") as f:
        img_base64 = base64.b64encode(f.read()).decode('utf-8')
    return img_base64

def histogram_equalization(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    equalized = cv2.equalizeHist(gray)
    return equalized

def sobel_edges(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    sobel = cv2.magnitude(sobelx, sobely)
    return np.uint8(sobel)

def laplacian_edges(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    return np.uint8(laplacian)


def process_image(image_file, operation):
    nparr = np.frombuffer(image_file.read(), np.uint8)
    image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    if operation == 'adaptive_threshold':
        processed_image = adaptive_threshold(image)
    elif operation == 'otsu_threshold':
        processed_image = otsu_threshold(image)
    elif operation == 'sharpen':
        processed_image = sharpen(image)
    elif operation == 'blur':
        processed_image = blur_image(image)
    elif operation == 'add_border':
        processed_image = add_border(image)
    elif operation == 'gamma':
        processed_image = gamma_correction(image)
    elif operation == 'histogram':
        return histogram(image)
    elif operation == 'histogram_equalization':
        processed_image = histogram_equalization(image)
    elif operation == 'sobel_edges':
        processed_image = sobel_edges(image)
    elif operation == 'laplacian_edges':
        processed_image = laplacian_edges(image)
    else:
        return None

    _, buffer = cv2.imencode('.png', processed_image)
    img_base64 = base64.b64encode(buffer).decode('utf-8')
    return img_base64

# Rotalar
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process():
    operation = request.form['operation']
    image_file = request.files['image']
    if image_file:
        result = process_image(image_file, operation)
        if result:
            return jsonify({'image': result})
    return jsonify({'error': 'Bir hata oluştu'}), 400

if __name__ == '__main__':
    app.run(debug=True)